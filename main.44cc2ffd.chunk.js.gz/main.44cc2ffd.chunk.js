(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ 102:
/***/ (function(module) {

module.exports = JSON.parse("[{\"y\":5,\"x\":1.5,\"name\":\"Yukon\",\"abbr\":\"Yuk.\",\"code\":\"YT\",\"c19cwg_name\":\"Yukon\",\"population\":41078},{\"y\":5,\"x\":2.5,\"name\":\"Northwest Territories\",\"abbr\":\"N.W.T.\",\"code\":\"NT\",\"c19cwg_name\":\"NWT\",\"population\":44904},{\"y\":5,\"x\":3.5,\"name\":\"Nunavut\",\"abbr\":\"Nun.\",\"code\":\"NU\",\"c19cwg_name\":\"Nunavut\",\"population\":39097},{\"y\":4,\"x\":1,\"name\":\"British Columbia\",\"abbr\":\"B.C.\",\"code\":\"BC\",\"c19cwg_name\":\"British Columbia\",\"population\":5110917},{\"y\":4,\"x\":2,\"name\":\"Alberta\",\"abbr\":\"Alta.\",\"code\":\"AB\",\"c19cwg_name\":\"Alberta\",\"population\":4413146},{\"y\":4,\"x\":3,\"name\":\"Saskatchewan\",\"abbr\":\"Sask.\",\"code\":\"SK\",\"c19cwg_name\":\"Saskatchewan\",\"population\":1181666},{\"y\":4,\"x\":4,\"name\":\"Manitoba\",\"abbr\":\"Man.\",\"code\":\"MB\",\"c19cwg_name\":\"Manitoba\",\"population\":1377517},{\"y\":3.5,\"x\":5,\"name\":\"Ontario\",\"abbr\":\"Ont.\",\"code\":\"ON\",\"c19cwg_name\":\"Ontario\",\"population\":14711827},{\"y\":3.5,\"x\":6,\"name\":\"Quebec\",\"abbr\":\"Que.\",\"code\":\"QC\",\"c19cwg_name\":\"Quebec\",\"population\":8537674},{\"y\":4,\"x\":7,\"name\":\"Newfoundland and Labrador\",\"abbr\":\"Nfld.\",\"code\":\"NL\",\"c19cwg_name\":\"NL\",\"population\":521365},{\"y\":2.5,\"x\":6,\"name\":\"New Brunswick\",\"abbr\":\"N.B.\",\"code\":\"NB\",\"c19cwg_name\":\"New Brunswick\",\"population\":779993},{\"y\":3,\"x\":7,\"name\":\"Prince Edward Island\",\"abbr\":\"P.E.I.\",\"code\":\"PE\",\"c19cwg_name\":\"PEI\",\"population\":158158},{\"y\":2,\"x\":7,\"name\":\"Nova Scotia\",\"abbr\":\"N.S.\",\"code\":\"NS\",\"c19cwg_name\":\"Nova Scotia\",\"population\":977457}]");

/***/ }),

/***/ 159:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 160:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 161:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 162:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 180:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 181:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 185:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 186:
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ 187:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__(140);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(31);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(155);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(156);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.assign.js
var es_object_assign = __webpack_require__(157);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(89);

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(90);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(16);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/regenerator-runtime/runtime.js
var runtime = __webpack_require__(54);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(35);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);

// EXTERNAL MODULE: ./src/css/normalize.css
var normalize = __webpack_require__(159);

// EXTERNAL MODULE: ./src/css/colors.css
var colors = __webpack_require__(160);

// EXTERNAL MODULE: ./src/css/fonts.css
var fonts = __webpack_require__(161);

// EXTERNAL MODULE: ./src/css/main.css
var main = __webpack_require__(162);

// EXTERNAL MODULE: ./node_modules/d3/index.js + 296 modules
var d3 = __webpack_require__(0);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(55);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(33);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.split.js
var es_string_split = __webpack_require__(94);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__(165);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(166);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__(167);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(97);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__(98);

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.search.js
var es_string_search = __webpack_require__(170);

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.url.js
var web_url = __webpack_require__(172);

// CONCATENATED MODULE: ./src/js/helper-functions.js











var helper = {
  getUrlParam: function getUrlParam(param) {
    var defaultResult = null;
    var queryString = window.location.search;
    var urlParams = new URLSearchParams(queryString);
    var paramValue = urlParams.get(param); // is there a value?

    paramValue = paramValue ? paramValue.toUpperCase() : defaultResult; // check if the province is a value province code

    if (param === 'prov') {
      paramValue = this.validProvinceCodes.includes(paramValue) ? paramValue : 'BC';
    }

    return paramValue;
  },
  map: function map(num, in_min, in_max, out_min, out_max) {
    return (num - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
  },
  months: ['Jan.', 'Feb.', 'Mar.', 'Apr.', 'May', 'June', 'July', 'Aug.', 'Sept.', 'Oct.', 'Nov.', 'Dec.'],
  numberWithCommas: function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  },
  validProvinceCodes: ['YT', 'NT', 'NU', 'BC', 'AB', 'SK', 'MB', 'ON', 'QC', 'NL', 'NB', 'PE', 'NS']
};
/* harmony default export */ var helper_functions = (helper);
// EXTERNAL MODULE: ./src/js/components/header/header.css
var header_header = __webpack_require__(180);

// CONCATENATED MODULE: ./src/js/components/header/header.js






var header_init = function init(data) {
  var endDay = data.date_end.split('-')[0];
  var endMonth = helper_functions.months[parseInt(data.date_end.split('-')[1]) - 1];
  var startDay = data.date_start.split('-')[0];
  var startMonth = helper_functions.months[parseInt(data.date_start.split('-')[1]) - 1];
  var startYear = data.date_start.split('-')[2];
  var startDate = startYear === '2020' ? "".concat(startMonth, " ").concat(startDay, ", 2020") : "".concat(startMonth, " ").concat(startDay);
  var endDate = startYear === '2020' ? "".concat(endMonth, " ").concat(endDay, ", 2021") : "".concat(endMonth, " ").concat(endDay);
  return "\n\t\t<h2>Active cases of COVID-19 from ".concat(startDate, " to ").concat(endDate, "</h2>\n\t\t<p>Red dots show where active cases have risen over the past month. Blue show where active cases have fallen. Provinces are coloured according to the previous days count of active cases per 100,000 people.</p>\n\t");
};

/* harmony default export */ var components_header_header = ({
  init: header_init
});
// EXTERNAL MODULE: ./src/js/components/topline-summary/topline-summary.css
var topline_summary = __webpack_require__(181);

// CONCATENATED MODULE: ./src/js/components/topline-summary/topline-summary.js







var topline_summary_metric = function metric(_metric, value, latest, date) {
  return "\n\t\t<div class=\"container ".concat(_metric.toLowerCase().replace(' ', '-'), "\">\n\t\t\t<h1>").concat(helper_functions.numberWithCommas(value), "</h1>\n\t\t\t<p class=\"metric-name\">").concat(_metric, "</p>\n\t\t</div>\n\t");
};

var topline_summary_timestamp = function timestamp(dateString) {
  var d = dateString.split('-');
  var month = helper_functions.months[+d[1] - 1];
  return "\n\t\t<p class=\"timestamp\">Last update: ".concat(month, " ").concat(d[0], ", ").concat(d[2], "</p>\n\t");
};

/* harmony default export */ var topline_summary_topline_summary = ({
  metric: topline_summary_metric,
  timestamp: topline_summary_timestamp
}); // <p class="metric-latest">${helper.numberWithCommas(latest)}</p>
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.for-each.js
var es_array_for_each = __webpack_require__(182);

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(184);

// EXTERNAL MODULE: ./node_modules/@flourish/popup/src/index.js + 5 modules
var src = __webpack_require__(103);

// CONCATENATED MODULE: ./src/js/sparkline.js
// https://www.essycode.com/posts/create-sparkline-charts-d3/


var sparkline_init = function init(data, el, size, tileHeaderHeight) {
  var dataCount = data.length - 1;
  var MARGIN = {
    top: 5,
    right: 5,
    bottom: 5 + tileHeaderHeight,
    left: 5
  };
  var INNER_WIDTH = size - MARGIN.left - MARGIN.right;
  var INNER_HEIGHT = size - MARGIN.top - MARGIN.bottom - tileHeaderHeight * 2;
  var x = Object(d3["f" /* scaleLinear */])().domain([0, dataCount]).range([0, INNER_WIDTH]);
  var y = Object(d3["f" /* scaleLinear */])().domain([0, Object(d3["d" /* max */])(data)]).range([INNER_HEIGHT, 0]);
  var line = Object(d3["c" /* line */])().x(function (d, i) {
    return x(i);
  }).y(function (d) {
    return y(d);
  });
  el.append('path').datum(data).attr('fill', 'none').attr('stroke', '#FFF').attr('stroke-width', 2).attr('d', line);
  el.append('circle').attr('r', 3).attr('cx', x(0)).attr('cy', y(data[0])).attr('fill', '#FFF').attr('stroke-width', 0);
  el.append('circle').attr('r', 4).attr('cx', x(dataCount)).attr('cy', y(data[dataCount])).attr('fill', data[0] < data[dataCount] ? '#E35D42' : 'steelblue').attr('stroke', '#FFF').attr('stroke-width', 0.5);
};

/* harmony default export */ var sparkline = ({
  init: sparkline_init
});
// EXTERNAL MODULE: ./src/js/components/TooltipTemplate/tooltip-template.css
var tooltip_template = __webpack_require__(185);

// CONCATENATED MODULE: ./src/js/components/TooltipTemplate/tooltip-template.js



function tooltip(data) {
  let death_graf;

  if (data.latest_deaths > 0) {
    death_graf = `<p>At least <span class="black">${helper_functions.numberWithCommas(data.latest_deaths)} people have died</span> in ${data.name} from the virus.</p>`;
  } else {
    death_graf = `<p>There haven’t been any deaths reported from the virus</span> in ${data.name}.</p>`;
  }

  const template = `
		<div class="tooltip-content">
			<h4>${data.name}</h4>
			<p>There are currently <span class="blue">${helper_functions.numberWithCommas(data.latest_active)} active cases</span> in ${data.name} – roughly ${data.latest_active_100k} cases per 100,000 people.</p>
			${death_graf}
		</div>
	`;
  return template;
}

;
/* harmony default export */ var TooltipTemplate_tooltip_template = (tooltip);
// EXTERNAL MODULE: ./src/js/components/canada-tilemap/canada-tilemap.css
var canada_tilemap = __webpack_require__(186);

// CONCATENATED MODULE: ./src/js/components/canada-tilemap/canada-tilemap.js









 // CSS


var coloursArray = ['#D4DAEA', '#AFBEDB', '#829DC7', '#6D8EBF', '#3C76B0', '#0062A3'];
var popup = Object(src["a" /* default */])();
var TILE_HEADER = 15;
var mobileBreakpoint = 500;
var marginMobile = {
  top: 50,
  right: 30,
  bottom: 25,
  left: 25
};
var marginWeb = {
  top: 50,
  right: 40,
  bottom: 50,
  left: 40
};
var elWidth, canada_tilemap_x, canada_tilemap_y, canada_tilemap_displayVariable;

var canada_tilemap_init = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee(el, data, timeseriesData, metric, legendTitle) {
    var label, square, margin, height, width, svg, scaleMax, colours;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            canada_tilemap_displayVariable = metric;
            label = 'abbr'; // OR 'code'

            square = d3["i" /* symbol */]().type(d3["j" /* symbolSquare */]); // calculations to jankily adjust map dimensions

            elWidth = document.querySelector(el).offsetWidth;
            margin = elWidth < mobileBreakpoint ? marginMobile : marginWeb;
            height = elWidth * 0.45;
            width = elWidth * 0.85; // scales

            canada_tilemap_x = d3["f" /* scaleLinear */]().range([0, width]);
            canada_tilemap_y = d3["f" /* scaleLinear */]().range([height, 0]); // Compute domains.

            canada_tilemap_x.domain(d3["b" /* extent */](data, function (d) {
              return d.x;
            })).nice();
            canada_tilemap_y.domain(d3["b" /* extent */](data, function (d) {
              return d.y;
            })).nice(); // SVG

            svg = d3["h" /* select */]('#map').append('svg').attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', 'translate(' + margin.left + ',' + margin.top + ')'); // add shapes

            drawShapes(svg, data, square); // add labels

            addLabels(svg, data, label); // sparklines

            addSparklines(svg, data, timeseriesData); // add colours & a legend

            scaleMax = d3["d" /* max */](data, function (d) {
              return d[canada_tilemap_displayVariable];
            });
            colours = assignColours(scaleMax);
            addLegend(map, colours, legendTitle, scaleMax, canada_tilemap_displayVariable); // set fill colour for shapes

            data.forEach(function (d) {
              d3["h" /* select */]("#".concat(d.code)).style('fill', colours(d[canada_tilemap_displayVariable]));
            });

          case 19:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function init(_x, _x2, _x3, _x4, _x5) {
    return _ref.apply(this, arguments);
  };
}();

function addLabels(svg, data, label) {
  var bbox = document.querySelector('.square').getBBox();
  var size = bbox.width;
  var margin = 10;
  svg.append('g').attr('class', 'labels').selectAll('labels').data(data).enter().append('text').attr('transform', function (d) {
    return "translate(".concat(canada_tilemap_x(d.x), ",").concat(canada_tilemap_y(d.y) - size / 2 + margin, ")");
  }).text(function (d) {
    return d[label];
  }).attr('class', 'label');
}

function addLegend(svg, legendScale, legendTitle, scaleMax, displayVariable) {
  var legend = d3["h" /* select */]('#map').append('div').attr('class', 'legend');
  legend.append('p').attr('class', 'legend-title').text(legendTitle);
  legend.append('div').attr('class', 'legend-fill');
  legend.append('p').attr('class', 'legend-value legend-value-left').text('0');
  legend.append('p').attr('class', 'legend-value legend-value-right').text("".concat(Math.floor(scaleMax / 10) * 10, "+"));
}

function addSparklines(svg, data, timeseriesData) {
  var bbox = document.querySelector('.square').getBBox();
  var size = bbox.width;
  var margin = 5;
  var container = svg.append('g').attr('class', 'sparklines').selectAll('container').data(data).enter().append('g').attr('id', function (d) {
    return d.code;
  }).attr('class', 'sparkline-container').attr('transform', function (d) {
    return "translate(".concat(canada_tilemap_x(d.x) - size / 2 + margin, ",").concat(canada_tilemap_y(d.y) - size / 2 + margin + TILE_HEADER, ")");
  }).attr('height', size - TILE_HEADER).attr('width', size).attr('stroke', '#000000'); // draw the sparklines

  timeseriesData.forEach(function (d) {
    sparkline.init(d.active_100k, d3["h" /* select */](".sparklines #".concat(d.code)), size, margin);
  });
}

function assignColours(scaleMax) {
  // colour scale (postmedia blue)
  return d3["g" /* scaleQuantile */]().domain([0, scaleMax]).range(coloursArray);
}

function drawShapes(svg, data, square) {
  // Add the points/shapes
  svg.append('g').attr('class', 'shapes').selectAll('square').data(data).enter().append('path').attr('id', function (d) {
    return d.code;
  }).attr('class', 'square').attr('d', square.size(function (d) {
    return Math.floor(elWidth * Math.sqrt(elWidth / 8));
  })).attr('transform', function (d) {
    return "translate(".concat(canada_tilemap_x(d.x), ",").concat(canada_tilemap_y(d.y), ")");
  }).on('mouseover', handleMouseenter).on('mouseout', handleMouseout);
}

function handleMouseenter(d) {
  popup.point(event.pageX, event.pageY).html(TooltipTemplate_tooltip_template(d, canada_tilemap_displayVariable)).draw();
}

function handleMouseout(d) {
  popup.hide();
}

/* harmony default export */ var canada_tilemap_canada_tilemap = ({
  init: canada_tilemap_init
});
// EXTERNAL MODULE: ./src/data/canada-tilemap.json
var data_canada_tilemap = __webpack_require__(102);

// CONCATENATED MODULE: ./src/index.js










// CSS



 // JS






 // import resp from './data/active.json';
// VARS

var variable = 'latest_active_100k';
var src_legendTitle = 'Active cases per 100,000'; // DATA

var dataUrl = 'https://vs-postmedia-data.sfo2.digitaloceanspaces.com/covid/covid-national-map.csv';
var toplineSummaryUrl = 'https://vs-postmedia-data.sfo2.digitaloceanspaces.com/covid/covid-national-summary.csv';

var src_init = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee() {
    var provCode, format, topline, resp, nested, data, header;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            provCode = helper_functions.getUrlParam('prov');
            format = helper_functions.getUrlParam('format');
            topline = helper_functions.getUrlParam('summary'); // topline summary metrics

            if (topline === 'TRUE') {
              d3["a" /* csv */](toplineSummaryUrl).then(function (data) {
                var topline = document.querySelector('#topline-summary');
                topline.innerHTML = buildSummaryBlocks(data[0]);
              });
            } // fetch data


            _context.next = 6;
            return d3["a" /* csv */](dataUrl);

          case 6:
            resp = _context.sent;
            // group data by province
            nested = d3["e" /* nest */]().key(function (d) {
              return d.name;
            }).entries(resp).map(function (d) {
              var latest = d.values[d.values.length - 1];
              return {
                name: d.key,
                code: d.values[0].code,
                short_name: d.values[0].short_name,
                active_100k: d.values.map(function (d) {
                  return parseFloat(d.active_100k);
                }),
                deaths_100k: d.values.map(function (d) {
                  return parseFloat(d.deaths_100k);
                }),
                latest_active_100k: parseFloat(latest.active_100k),
                latest_active: parseFloat(latest.active_cases),
                latest_cases: parseFloat(latest.cumulative_cases),
                latest_deaths: parseFloat(latest.cumulative_deaths),
                date_start: d.values[0].date_active,
                date_end: latest.date_active
              };
            });
            _context.next = 10;
            return joinData(nested, data_canada_tilemap);

          case 10:
            data = _context.sent;
            console.log(data); // build header

            header = document.querySelector('#header');
            header.innerHTML = components_header_header.init(data[0]); // build map

            canada_tilemap_canada_tilemap.init('#map', data, nested, variable, src_legendTitle);
            console.log("eli is not stinky btw");

          case 16:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function init() {
    return _ref.apply(this, arguments);
  };
}();

function buildSummaryBlocks(data) {
  var string = ''; // cases

  string += topline_summary_topline_summary.metric('Confirmed cases', +data.cumulative_cases, data.cases); // deaths

  string += topline_summary_topline_summary.metric('Deaths', +data.cumulative_deaths, data.deaths); // vaccinations

  string += topline_summary_topline_summary.metric('Vaccines administered', data.cumulative_avaccine, +data.avaccine); // timestamp

  string += topline_summary_topline_summary.timestamp(data.date);
  return string;
}

function joinData(data, shapes) {
  // join by prov code
  return shapes.map(function (s) {
    var dataProps = data.filter(function (d) {
      return d.name === s.name;
    })[0]; // delete dataProps.prov_code; // duplicate

    var joined = Object.assign({}, s, dataProps);
    return joined;
  });
}

src_init();

/***/ })

},[[187,1,2]]]);